# 从 git pull 到 CI/CD 流水线：MyBlog 学习实验报告

> 这不是一篇部署手册，而是一次**学习实验**的记录。实验对象是我的个人博客 MyBlog；实验目标很明确：通过一次真实改造，掌握 Jenkinsfile 的语法和流水线搭建方法，配合代码仓库的 Webhook 和私有镜像仓库 Registry，完成 CI 与 CD 的解耦，把项目从「手工发布」带入「生产级部署」。
>
> 下文按「背景 → 疑问 → 设计 → 步骤 → 踩坑 → 验收 → 结论」的实验脉络展开，重点讲清每一层为什么改、解决了什么问题、实验中踩过哪些坑。

## 一、实验背景与学习目标

### 1.1 实验对象

MyBlog 是一个前后端分离的个人博客系统，包含三个业务构建单元：

- Spring Boot 3.5 + Java 21 后端；
- Vue 3 + TypeScript 博客前台；
- Vue 3 + TypeScript 管理后台。

运行时还依赖 PostgreSQL、Redis 和 Nginx。项目早期规模不大时，我采用最直接的部署方式：服务器上保留一份 Git 工作区，更新时执行 `git pull`，再让 Docker Compose 从当前源码重新构建并启动所有服务：

```bash
cd /path/to/myblog
git pull origin master
docker compose up -d --build
docker compose ps
```

### 1.2 学习目标

- 理解并动手编写 Jenkinsfile（Declarative Pipeline）的阶段、agent、stash 等语法；
- 搭建完整的 CI/CD 流水线，并理解 CI（持续集成）与 CD（持续交付/部署）各自的职责；
- 学会用 GitHub 分支保护 + Webhook 控制代码入口和构建触发；
- 搭建私有镜像仓库 Registry，把镜像变成可追溯的发布记录；
- 建立可回滚、可验收的生产发布流程。

## 二、起点：旧部署方式回顾

旧方案的概念少、搭建快，一个 Compose 文件就编排了数据库、缓存、后端、前端和网关，在项目早期确实很省心。但当我想给项目加 HTTPS、让后台走独立路由、引入回滚能力时，逐渐发现「能部署」和「能可控地发布」是两回事。

![图 1　旧方案发布流程：源码、构建、部署全部耦合在生产服务器上](images/old-flow.png)

*图 1　旧方案发布流程：源码、构建、部署全部耦合在生产服务器上*

这套流程的核心特征是：**源码、构建、部署和运行环境全部耦合在生产服务器上**。服务器既运行业务，又承担发布时的全部构建工作，整个链路没有任何机器可验证的检查点。

## 三、驱动实验的三个疑问

旧方案没有绝对的错误，但它留下了三个我想通过这次实验亲手回答的问题。

### 3.1 疑问一：流水线到底怎么搭？Jenkins 怎么用？

`docker compose up -d --build` 会在生产服务器上执行 Maven、npm 和 Docker build，服务器既要运行 PostgreSQL、Redis 和应用，又要在发布时承担 CPU、内存和磁盘压力。更重要的是，生产环境构建出的镜像依赖当时的工作区、缓存和基础镜像状态——即使 Git commit 相同，构建过程也未必有清晰的可追溯性。

需要说明的是：本实验中 Jenkins、Registry 和业务容器仍部署在同一台服务器，Jenkins 也通过宿主机 Docker Socket 构建镜像。所以新方案解决的是**职责、工作区和发布流程的隔离**，并没有消除单机资源竞争；未来可以把 Jenkins Agent 迁到独立构建机，而不改变 CI/CD 契约。

### 3.2 疑问二：测试检查能否自动化？

项目其实已经具备不错的检查能力：后端有单元测试、Testcontainers 集成测试、Checkstyle、SpotBugs、JaCoCo 和 ArchUnit；两个前端有 ESLint、TypeScript 类型检查和 Vite 构建。但如果这些检查靠开发者手动执行，就必然会有遗漏。旧流程中，「拉取成功」与「可以发布」之间没有机器可验证的契约。

### 3.3 疑问三：CI 和 CD 怎么解耦？

如果镜像只有 `latest` 标签，或者只是服务器本地临时构建，就很难快速回答下面几个问题：

- 当前线上运行的是哪个 Git commit？
- 前台、后台和后端是否来自同一次构建？
- 上一个稳定版本是什么？
- 回滚时应该恢复哪三个镜像？

没有稳定版本号，回滚往往会退化成「切换代码、重新构建、再试一次」——**这不是真正意义上的可重复回滚**。

## 四、实验设计：六条规则与两套 Compose

带着这三个疑问，我给这次改造设定了六条规则，作为整个实验的设计约束：

1. 生产 Compose 和 CD 阶段不再从源码构建业务镜像；
2. 只有通过质量门的产物才能进入镜像；
3. 前台、后台、后端必须共享同一个不可变 release tag；
4. CD 只部署指定 tag，不接收模糊的 `latest`；
5. 部署成功必须经过健康检查，并记录最后一次成功版本；
6. `master` 通过 GitHub PR 保护，构建、部署和镜像清理各自有独立流程。

同时，项目保留两套 Compose 文件，避免把本地开发的便利性和生产发布的纪律混在一起：

| 使用场景 | Compose 文件 | 镜像来源 | 网关 | 依赖 Jenkins/Registry |
|---|---|---|---|---|
| 本地一键部署 | `docker-compose.yml` | 当前源码构建 | HTTP | 否 |
| 生产 CI/CD | `deploy/docker-compose.yml` | CI 推送的不可变镜像 | HTTPS | 是 |

生产 Compose 完全没有 `build` 字段，三个业务镜像必须由 CD 通过环境变量 `API_IMAGE`、`WEB_IMAGE`、`ADMIN_IMAGE` 注入。这是一条重要的环境边界：

> **本地方案优化开发效率，生产方案优化可追溯性和可恢复性。**

## 五、新方案整体架构

![图 2　新方案整体架构](images/new-arch.png)

*图 2　新方案整体架构：GitHub → Jenkins CI → 私有 Registry → 手动 CD → 生产环境*

新流程把一次发布拆成了三个可以单独理解的动作，这也是本实验对 CI/CD 解耦的核心体会：

- **GitHub 决定什么代码可以进入 master**（代码入口）；
- **CI 决定什么 commit 可以成为发布镜像**（质量门 + 制品生产）；
- **CD 决定哪个已经验证的版本在什么时候上线**（发布决策）。

## 六、步骤一：用 GitHub 管住代码入口

CI/CD 的起点不是 Jenkins，而是代码仓库。如果 `master` 可以被任意直接推送，后面的流水线再严格，也只能验证一个缺少审核过程的结果。

### 6.1 分支保护规则

在 GitHub Branch protection / Ruleset 中对 `master` 设置五条规则：

1. 所有变更必须通过 Pull Request 合并；
2. 禁止直接 push `master`；
3. 禁止 force push 和删除 `master`；
4. 根据协作人数设置审批数量；
5. 功能分支提交和 PR 更新不触发生产 CI，只有 PR 合并形成的 `master` push 才触发。

日常代码路径因此变成：

```text
feature/fix 分支 → commit → push → PR → review → merge → master
```

GitHub 只负责变更入口和审核记录，Jenkins 不需要向仓库写代码的权限——私有仓库配置只读 PAT 或 SSH 凭据即可，公开仓库甚至可以匿名拉取。生产密钥不写入 GitHub，而是保存在服务器的 `deploy/.env` 和 Jenkins 运行环境中。

### 6.2 Webhook 触发方式

Jenkins 通过生产 Nginx 的 HTTPS 路径对外暴露，Webhook 地址形如：

```text
https://<BLOG_DOMAIN><JENKINS_ROUTE>/github-webhook/
```

Webhook 只订阅 push 事件；生产 Multibranch Pipeline 用正则 `^master$` 过滤分支，不启用 PR discovery，也不启用 Poll SCM，从而避免功能分支 push、PR 创建和更新重复触发生产构建。

### 6.3 一个明确的取舍

当前 Jenkins CI 是「PR 合并后的发布质量门」，不是 GitHub 合并前的 required status check。也就是说，CI 失败时失败的 commit 已经进入 `master`，只是不会生成可部署版本。这个设计适合个人项目「控制资源消耗、只为候选发布版本跑完整流水线」的目标；若未来希望合并前就拦住问题代码，需要让 Jenkins 发现 PR 并回写状态，并把该检查设为必需状态。

## 七、步骤二：Jenkins CI——先验证，再封装镜像

CI 的实现位于 `Jenkinsfile.ci`。顶层使用 `agent none`，每个阶段按需申请节点或容器，避免整条流水线长期占用同一种执行环境。

### 7.1 流水线阶段总览

| 阶段 | 主要工作 | 失败后的结果 |
|---|---|---|
| Prepare | 校验 Docker Socket GID，读取并校验 `ADMIN_ROUTE` | 不进入构建 |
| Backend CI | 执行 `mvn -B verify`，归档 JUnit 与 JaCoCo 报告 | 不产生后端发布物 |
| Frontend CI | 前台、后台并行执行安装、lint、类型检查和构建 | 不产生前端发布物 |
| Build Images | 只在 `master` 封装三个已验证的产物 | 不推送镜像 |
| Push Images | 加锁推送、读取三个 digest、归档 `release.env` | 不宣布可部署版本 |

### 7.2 后端质量门：mvn verify 做了什么

后端在 `maven:3.9-eclipse-temurin-21` 容器中运行 `mvn -B verify`。这条命令不是简单编译，它串联了七项检查：

- JUnit 单元测试；
- Failsafe `*IT` 集成测试；
- Testcontainers 启动真实 PostgreSQL 和 Redis；
- Checkstyle 代码规范检查；
- SpotBugs 静态分析；
- JaCoCo 覆盖率报告；
- ArchUnit 分层依赖约束。

Jenkins 会收集 Surefire/Failsafe XML 报告并发布 JaCoCo 结果；后端产出的 JAR 用 `stash` 暂存，后续镜像阶段只拿这份「已经验证的 JAR」。由于 Testcontainers 需要启动容器，Maven 容器必须挂载宿主机 `/var/run/docker.sock`——这正是后面 Docker GID 权限问题的根源（见 12.2）。

### 7.3 前端并行质量门

博客前台和管理后台在两个 `node:20-alpine` 执行环境中并行运行：

```bash
npm ci --no-audit --no-fund
npm run lint
npm run build
```

项目的 `build` 脚本内部包含 `vue-tsc`，因此 TypeScript 类型错误会直接让流水线失败。管理后台构建还会注入 `VITE_ADMIN_ROUTE`，确保 Vite base 与生产 Nginx 的后台路径一致。两个 `dist` 同样通过 `stash` 交给镜像阶段。并行执行减少了串行等待，又保持前后台结果互不掩盖。

### 7.4 「构建一次，封装一次」

CI 不在业务 Dockerfile 里重新执行 Maven 或 npm，而是先完成全部验证，再用 `deploy/images/` 下的运行时 Dockerfile 封装结果：

- `myblog-api`：JRE 21 + 已验证 JAR；
- `myblog-web`：Nginx + 已验证前台 `dist`；
- `myblog-admin`：Nginx + 已验证后台 `dist`。

这样保证「通过测试的产物」和「放进镜像的产物」是同一份，而不是在镜像阶段重新编译出另一份结果。

### 7.5 不可变 release tag：commit 如何变成「可部署版本」

三个镜像共用同一个 tag，格式为「日期时间-7 位 Git SHA」：

```text
yyyyMMdd-HHmmss-7位GitSHA

127.0.0.1:5000/myblog-api:20260826-153000-a1b2c3d
127.0.0.1:5000/myblog-web:20260826-153000-a1b2c3d
127.0.0.1:5000/myblog-admin:20260826-153000-a1b2c3d
```

项目不创建 `latest`。镜像还通过 OCI Label 记录 version、完整 Git SHA 和 UTC 构建时间，管理后台镜像额外记录 `com.myblog.admin-route` 标签。只有三个镜像全部推送成功、并且 Registry API 能读取到合法的 `sha256` digest 后，Jenkins 才归档 `release.env`：

```dotenv
RELEASE_TAG=20260826-153000-a1b2c3d
RELEASE_REVISION=<完整GitSHA>
RELEASE_CREATED=<UTC时间>
```

到这一步，一个 Git commit 才真正变成**可部署版本**——这是 CI 阶段的终点，也是 CD 阶段的起点。

## 八、步骤三：私有 Registry——把镜像当作发布记录

Registry 用独立的 `deploy/registry/docker-compose.yml` 管理，与博客应用生命周期解耦。关键约束：

- 使用官方 `registry:2` 镜像；
- 数据持久化到 `/data/registry`；
- 只绑定 `127.0.0.1:5000`，不向公网开放；
- Jenkins 通过外部网络 `myblog-cicd` 访问 `registry:5000`；
- 开启 manifest 删除，为后续垃圾回收做准备。

这是本机 HTTP Registry：宿主机 Docker 走回环地址访问，Jenkins 容器走隔离网络访问，均不暴露公网。若未来改为跨主机 Registry，必须增加 TLS、认证和独立备份，不能原样暴露当前 HTTP 端口。

### 8.1 为什么要同时校验 tag 和 digest

tag 是给人看的版本名，digest 才是镜像内容的唯一标识。CI 推送后、CD 部署前，都通过 `scripts/registry-api.sh` 调用标准的 Docker Registry V2 HTTP API 获取 digest 并校验格式。这比「执行 `docker push` 后默认它已经可用」多了一层明确确认，也避免额外依赖非标准的 Registry CLI。

### 8.2 推送、部署与清理共用一把文件锁

CI 推送、CD 拉取和 Registry 清理三类任务，共同通过 `flock` 串行访问同一把锁：

```text
/var/jenkins_home/locks/myblog-registry.lock
```

这个细节看似只是脚本同步，实际解决的是「多个正确的流程并发执行后产生错误结果」的问题——例如垃圾回收与镜像推送同时发生。

## 九、步骤四：Jenkins CD——部署的是版本，不是工作区

CD 的实现位于 `Jenkinsfile.cd`，被故意设计为手动参数化 Job：操作者必须填写 CI 生成的 `IMAGE_TAG`。

### 9.1 为什么 CD 不跟随 CI 自动执行

项目把「生成可发布版本」和「让版本上线」两件事分开：CI 自动证明版本满足质量门；CD 由操作者选择发布时间和目标 tag；回滚与普通部署走同一条 CD 路径。对单机个人项目，这比每次合并都立即上线更稳妥，也保留了发布窗口和人工确认。

### 9.2 部署前预检：七道关卡

CD 在修改运行中容器之前，依次确认：

1. `IMAGE_TAG` 符合 release tag 格式；
2. Registry 容器状态为 `healthy`；
3. Jenkins 能访问 Registry 的 `/v2/` 接口；
4. 三个仓库都存在这个 tag；
5. 三个 manifest digest 都合法；
6. 三个完整镜像都能拉取；
7. admin 镜像中的 `ADMIN_ROUTE` 与生产配置一致。

任一预检失败，CD 都不会执行 `docker compose up`，线上容器保持原状。其中 `ADMIN_ROUTE` 检查尤其重要：管理后台的 Vite base 在构建时就写进了静态文件，而 Nginx 路径来自部署配置，两者不一致时页面可能正常打开、但 JS/CSS 和前端路由全部 404。把构建路径写入镜像 Label、再在 CD 中比对，可以把这类问题挡在部署之前。

### 9.3 无构建部署

预检通过后，CD 注入三个完整镜像地址并执行：

```bash
docker compose \
  --env-file /opt/myblog/deploy/.env \
  -f deploy/docker-compose.yml \
  up -d --no-build
```

`--no-build` 参数与生产 Compose 中不存在 `build` 字段构成双重约束：服务器部署阶段只做镜像拉取和容器编排，不再受源码工作区和构建缓存影响。

### 9.4 健康检查与成功版本状态

部署后，CD 轮询 backend、frontend-web、frontend-admin、nginx 四个服务的 Docker health status。全部健康后，才用「临时文件 + 原子移动」的方式更新当前成功版本记录：

```text
/data/jenkins/deploy-state/myblog-current-release
```

如果部署失败，状态文件不会更新；流水线保留失败容器现场，打印服务状态、最近日志和手动回滚命令，但不自动回滚。选择不自动回滚，是因为自动回滚可能覆盖最有价值的失败现场，而且健康检查失败不意味着旧容器可以无条件恢复——对单机项目，保留现场并让操作者选择旧 tag 更容易理解和审计。

### 9.5 回滚：与发布是同一种操作

回滚不需要切 Git 分支，也不需要重新构建——只要在 CD Job 中填写仍被保留的旧 tag，就会重新执行同样的预检、拉取、部署和健康检查。

> **发布和回滚终于成为同一种操作：选择一个已经验证过的版本并部署。**

## 十、镜像仓库的生命周期管理

镜像仓库不能只管推送、不管增长。项目用 `Jenkinsfile.registry-cleanup` 每天北京时间 03:30 调用 `scripts/registry-cleanup.sh`，每个仓库的保留规则是：

> **最近 5 个合法 release tag + 当前成功部署 tag（最多保留 6 个）。**

如果当前版本已在最近 5 个里就保留 5 个；如果线上仍运行较旧版本，就额外保护它。删除前脚本会先确认：

- 当前成功版本状态文件存在且格式正确；
- 后端、前台、后台各有且只有一个运行容器；
- 三个运行容器与状态文件使用同一 tag；
- 三个仓库都存在当前 tag；
- Registry 健康且 API 可用。

任何检查失败都会在删除前退出。正式清理时，先通过 V2 API 删除旧 manifest，再短暂停止 Registry 执行 garbage collection，最后重启并等待恢复健康。

生产配置默认 `REGISTRY_CLEANUP_DRY_RUN=true`：先观察删除计划，再显式改为 `false`。这比一开始就启用定时删除更符合运维实验的安全顺序。

## 十一、网络入口与敏感配置

### 11.1 唯一公网入口

生产 Nginx 是唯一公网入口：80 端口 301 跳转 HTTPS，443 端口承载博客、管理后台、API 和 Jenkins。Jenkins 正式运行时不映射宿主机端口，只通过 `JENKINS_ROUTE` 环境变量对应的路径反向代理；首次初始化时临时绑定到 `127.0.0.1:8888`、配合 SSH 隧道访问，正式入口可用后即移除。Registry 只绑定 `127.0.0.1:5000`，PostgreSQL、Redis 和后端调试端口也只绑定回环地址，服务器安全组只需开放 SSH、HTTP 和 HTTPS。

### 11.2 配置与代码分离

生产配置来自 `deploy/.env`，该文件不提交 Git，仓库只保存 `deploy/.env.example` 作为变量契约。数据库密码、Redis 密码、会话空闲时间、访客哈希密钥、OSS 凭据和初始管理员密码都在服务器侧填写；旧 `JWT_SECRET` 只在回滚观察期保留，新版本不再读取。这解决了敏感信息入库问题，但也意味着 `deploy/.env` 需要独立备份和权限控制——Git 不会替我们管理生产密钥。

## 十二、踩坑记录：实验中最有价值的部分

这次改造最有价值的，不是第一次把 Jenkinsfile 写出来，而是把「偶尔能跑」修正为「边界清晰地运行」。下面七个问题各按「现象 → 原因 → 修复 → 收获」记录。

### 12.1 顶层 agent none 下调 sh：缺少节点上下文

**现象**：流水线进入正式阶段前报错 `MissingContextVariableException: hudson.FilePath is missing`。

**原因**：Declarative Pipeline 顶层是 `agent none`，此时没有分配节点和 workspace；但早期实现试图在顶层 `environment` 块中调用 `sh` 读取 `DOCKER_GID`。

**修复**：把读取和校验移动到 Prepare 阶段，在 `agent any` 已获得节点后执行，结果保存为 `env.DOCKER_SOCKET_GID`。

**收获**：Jenkins 的环境变量声明不等于普通 Shell 初始化。凡是依赖 workspace、文件或命令执行的值，都必须放在有节点上下文的阶段中计算。

### 12.2 Docker Socket 的 GID 在三层环境中必须一致

Jenkins 自己运行在容器里，后端测试运行在 Maven 容器里，Testcontainers 又要访问宿主机 Docker Socket 启动子容器——这里实际有三层环境：

![图 3　Docker-outside-of-Docker 的三层权限链](images/docker-layers.png)

*图 3　Docker-outside-of-Docker 的三层权限链：挂载 Socket 只是第一步*

只挂载 `/var/run/docker.sock` 并不代表有权限访问。项目在服务器配置中记录 `DOCKER_GID`，Jenkins Compose 使用 `group_add` 把 Jenkins 加入 docker 组，CI 的 Prepare 阶段再把配置值与 Socket 实际 GID 比对，最后通过 `--group-add` 传给 Maven 容器。由于运行期 GID 不能安全地直接插值到 Declarative 的 `agent` 块，后端阶段改为在已分配的节点中调用 `docker.image(...).inside(...)`。

**收获**：Docker-outside-of-Docker 的关键不只是挂载 Socket，还包括宿主机组权限、容器组权限和 Jenkins 的执行时机。

### 12.3 后台构建路径与部署路径不一致

**现象**：后台首页可能返回 200，但静态资源或前端路由 404。

**原因**：后台 Vite base 在构建时确定，而 Nginx 的 `ADMIN_ROUTE` 在部署时读取；两个阶段用了不同配置，容器健康检查未必能发现浏览器侧的资源路径问题。

**修复**：CI 从生产配置读取并校验 `ADMIN_ROUTE`，构建后台时注入相同值并写入镜像 Label；CD 部署前再次比较 Label 和生产配置。

**收获**：对编译期配置，不能只依赖运行时环境变量，必须把它纳入制品契约。

### 12.4 Registry 工具依赖与 API 契约

早期方案依赖额外的 Registry CLI，后来改为用 `curl`、`jq` 和标准 Docker Registry V2 HTTP API 完成 ping、tag 查询、digest 查询和 manifest 删除。

**收获**：运维流水线中优先使用稳定、可验证的标准协议，可以减少工具安装、版本和架构兼容问题。

### 12.5 Registry 清理与推送并发

**风险**：垃圾回收期间如果 CI 仍在推送、或 CD 正在拉取，可能出现 manifest 与 blob 状态竞争。

**修复**：CI、CD 和 Cleanup 共用同一把 `flock` 文件锁；清理任务在执行删除前完成全部一致性检查。

**收获**：自动化任务单独运行正确还不够，还要考虑它们同时运行时是否正确。

### 12.6 非 root 后端与宿主机日志目录权限

生产 API 镜像用非 root 的 `myblog` 用户运行，日志却通过 bind mount 写入宿主机 `APP_LOG_DIR` 环境变量指定的目录。如果目录由 root 或其他 UID 创建，应用会因无写权限而启动失败。项目没有让 Compose 或 CD 以 root 自动改宿主机目录，而是在首次 CD 前，从指定 API 镜像读取 `myblog` 的实际 UID/GID，再手动创建并 `chown` 日志目录；镜像用户变化、迁移服务器或重建目录时需要重新执行。

**收获**：容器内用户名不会自动映射宿主机权限，bind mount 最终识别的是数字 UID/GID。

### 12.7 Jenkins 工具镜像的软件源问题

Jenkins 镜像需要安装 Docker CLI、Buildx、Compose、`curl`、`jq` 和 `flock`。实验中遇到 Debian 与 Docker CE 软件源访问不稳定的问题，因此自定义 Jenkins 镜像在首次 `apt-get update` 前统一替换镜像源，并把 Docker APT 镜像做成构建参数。

**收获**：流水线依赖的工具链本身也应该镜像化和版本化，不能把「服务器上刚好装过」当成可复制的环境。

## 十三、如何验收这套流水线

实验的验收分为四组，每组都是可以实际操作的检查项。

### 13.1 代码入口

- 功能分支 push 不触发生产 CI；
- PR 创建和更新不触发生产 CI；
- `master` 不能直接 push 或 force push；
- PR 合并后的 `master` push 只触发一次 CI。

### 13.2 CI

- 后端单测、集成测试或静态检查失败时不构建发布镜像；
- 任一前端 lint、类型检查或构建失败时不构建发布镜像；
- 三个仓库生成相同 release tag，且都能读取合法 digest；
- `release.env` 中的 tag、Git SHA 和构建时间可追溯。

### 13.3 CD

- 空 tag、非法 tag 和不存在的 tag 在部署前失败；
- Registry 故障时不修改运行中容器；`ADMIN_ROUTE` 不匹配时不部署；
- CD 日志中不出现 `docker build`；
- 四个服务全部健康后才更新当前版本状态文件；部署失败时状态文件保持旧值。

### 13.4 回滚与清理

- 选择旧 tag 可以走同一 CD 流程恢复；
- 当前线上 tag 即使不在最近 5 个中也不会被清理；
- 三个运行容器版本不一致时清理任务直接退出；
- Dry Run 只输出计划不删除；Cleanup 持锁时，CI 推送和 CD 拉取会等待。

## 十四、新旧方案对比与实验结论

| 维度 | 旧方案：git pull + 现场构建 | 新方案：GitHub + Jenkins + Registry |
|---|---|---|
| 代码入口 | 可直接更新 master | 功能分支 + PR + master 保护 |
| 触发方式 | SSH 后手工执行命令 | 合并触发 CI，人工选 tag 执行 CD |
| 质量检查 | 依赖人工记忆或夹在镜像构建中 | 前后端都有显式质量门 |
| 发布物 | 本地镜像或浮动 latest | 三个同版本不可变镜像 |
| 版本关联 | 代码、镜像、容器关系模糊 | tag、Git SHA、OCI Label、digest 可追溯 |
| 生产部署 | 拉源码重新构建 | 只拉指定镜像，--no-build 部署 |
| 失败判断 | 人工查看日志和页面 | 预检 + Docker 健康检查 |
| 回滚 | 切代码重建，结果可能变化 | 选择保留的旧 tag 重新部署 |
| 镜像空间 | 手工 prune | 定时保留最近版本并保护线上版本 |
| 并发控制 | 无 | 推送、拉取、清理共享 Registry 锁 |
| 对外暴露 | 易临时开放多个管理端口 | Nginx HTTPS 唯一入口 |
| 主要代价 | 发布风险随复杂度增长 | 初始搭建复杂，需维护 Jenkins/Registry |

![图 4　新旧方案链路对比](images/compare.png)

*图 4　新旧方案链路对比：短链路耦合 vs 长链路分层*

旧方案是一条短链路，但每一步都依赖服务器当前状态和操作者经验；新方案链路更长，却把代码审核、质量验证、制品管理、部署决策和运行验收拆成了可观察、可失败、可重试的阶段。

### 14.1 这次实验真正学到的东西

最初我把 CI/CD 理解成「代码 push 后自动执行几条命令」。做完这次改造后，更准确的理解是：

> **CI/CD 的核心不是自动化命令数量，而是建立从代码到运行版本的可信链路。**

这条链路需要回答四个问题：

1. 这段代码是否经过了受控入口？
2. 这个制品是否通过了约定的质量检查？
3. 线上运行的是否就是被验证过的那份制品？
4. 失败时能否识别并恢复到一个明确版本？

### 14.2 后续演进方向

- 增加合并前 PR CI，并把状态检查设为 GitHub 必需条件；
- 为跨主机 Registry 增加 TLS、认证、备份和容量监控；
- 增加 Jenkins 配置即代码（JCasC）和凭据备份；
- 把健康检查扩展为真实业务 smoke test；
- 停机窗口不可接受时，引入滚动、蓝绿或双机部署；
- 增加发布通知、耗时趋势和失败原因统计。

这次改造没有追求一次性搭建「最复杂」的平台，而是从项目真实痛点出发，把手工发布逐步替换成一条可以解释、验证和回滚的工程链路。对个人项目来说，这种演进比单纯堆叠工具更有学习价值。

### 14.3 参考实现

- CI 流水线：`Jenkinsfile.ci`
- CD 流水线：`Jenkinsfile.cd`
- Registry 清理流水线：`Jenkinsfile.registry-cleanup`
- 生产镜像编排：`deploy/docker-compose.yml`
- Jenkins 编排：`deploy/jenkins/docker-compose.yml`
- Registry 编排：`deploy/registry/docker-compose.yml`
- Registry 清理脚本：`scripts/registry-cleanup.sh`
- CI/CD 设计约束：`docs/CI-CD.md`；生产部署指南：`deploy/README.md`
